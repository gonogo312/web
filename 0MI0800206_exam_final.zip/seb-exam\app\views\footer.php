<?php

?>
<footer class="site-footer">
    <div class="container">
        <p>&copy; <?= date('Y') ?> <?= e(APP_NAME) ?> &mdash; Local XAMPP System</p>
    </div>
</footer>


